// Michael Theisen

#include <stdio.h>
#include "loan.h"

int main()
{
	LoanType* loanObj1 = create(9000.01, 9.90, 12);
	LoanType* loanObj2 = create(3.50, 5.71, 24);
	
	printf("\n\n\nYour first loan details are:\n\n");
	print(loanObj1);
	
	printf("and the details of your second loan are:\n\n");
	print(loanObj2);
	
	LoanType* loanObj=consolidate(loanObj1,loanObj2);
	printf("If you wish to consolidate your loans, we can offer you:\n\n\n");
	
	print(loanObj);

	destroy(loanObj1);
	destroy(loanObj2);
	destroy(loanObj);
	
	return 0;
}

