// Michael Theisen

#ifndef LOAN_H // ifndef 
#define LOAN_H

// pointer to struct loan typedefd LoanType
typedef struct loan LoanType;

// the prototypes.
LoanType* create(float balance, float apr,int length);
void destroy(LoanType* loanObj);
LoanType* consolidate(LoanType* loanObj1, LoanType* loanObj2);
void print(LoanType* loanObj);
char* toString(int n1, float n2,char type);



#endif

