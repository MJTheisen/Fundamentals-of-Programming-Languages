// Michael Theisen 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>




void cleanString(char string[]);
// takes in string, modifies it, no return, removes all non letters
// call cleanString("1809 Lincoln!") should result in "Lincoln"
// ctype library

char* makeAcronym(char string[], int words);
// takes a string that consists of a few words delimited by blanks
// and integer denotes the number of words in the string
// function returns a new, dynamically allocated string that is a capitalized acronym
// include the null \0.


int main() 
{
  // printf("%s\n\n", cleanString("1809 Lincoln!"));
  // printf("%s\n\n", cleanString("MmIiCcHhAaEeLl!@#$%^&*1234567890"));
  // why doesnt this work? "invalid use of void expression"
  
     printf("%s\n\n", makeAcronym("\n\n As seen on screen", 4 ));
     printf("%s\n\n", makeAcronym("\n\n Why doesnt my cleanString work?", 5));


	return 0;
}


void cleanString(char string[])
{
        char* newString = malloc(sizeof(char) * (strlen(string)+1));
        int i = 0, j = 0;
	while (string[i] != '\0')
	{
	       if ((string[i] >= 'A' && string[i] <= 'Z') || 
	 	   (string[i] >= 'a' && string[i] <= 'z'))
	       {
	       newString[j++] = newString[i];
               }
	i++;
	}
        newString[j] = '\0';
       // printf("%s", newString);
	free (newString);
}


char* makeAcronym(char string[], int words)
{
        char* acrString = malloc(sizeof(char) * (words + 1));
        int i = 1, j = 1;

	acrString[0] = string[0];
        
        while (string[i] != '\0')
	{
	       if(string[i] == ' ')
	       {
                        acrString[j] = toupper(string[i+1]);
			//easier than cycling through all the letters
	                i = i+2;
	                j++;

	       }
	       else
	       {
	              	i++;
	       }
	}
        return acrString;
	free(acrString);
}
		
















