// Michael Theisen

#include <stdio.h>
#include "loan.h"
#include <stdlib.h>

struct loan 
{
	float balance, apr;
	int length; //in months
};

// create 
LoanType* create(float balance, float apr,int length)
{
	LoanType* loanObj = (LoanType*)malloc(sizeof(LoanType));
	loanObj->balance = balance;
	loanObj->apr = apr;
	loanObj->length = length;
	//returns a pointer to a loan object dynamically allocated on the heap, "loanObj"
	return loanObj;
}

// free malloc
void destroy(LoanType* loanObj)
{
	free(loanObj);
}

// consolidation. adding and choosing
LoanType* consolidate(LoanType* loanObj1, LoanType* loanObj2)
{
	LoanType* loanObj = (LoanType*)malloc(sizeof(LoanType));
	// balance on the new loan is the sum of the two individual loan balances
	loanObj->balance = loanObj1->balance + loanObj2->balance;
	
	// apr is the lower apr of the two
	if(loanObj1->apr < loanObj2->apr)
		//if the value of the first apr is lower
		loanObj->apr = loanObj1->apr;
	else
		//if the value of the second apr is lower
		loanObj->apr = loanObj2->apr;
	
	//length is the higher of the two lengths in months
	if(loanObj1->length > loanObj2->length)
		loanObj->length = loanObj1->length;
	else
		loanObj->length = loanObj2->length;
	
	return loanObj;
}

void print(LoanType* loanObj)
{
	printf("        BALANCE: %f, APR: %f%%, LENGTH: %d MONTHS\n\n\n", loanObj->balance, loanObj->apr, loanObj->length);
}
